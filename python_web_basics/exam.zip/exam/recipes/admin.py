from django.contrib import admin

from recipes.models import Recipe

admin.site.register(Recipe)
